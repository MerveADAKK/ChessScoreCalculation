package com.company;

//Kale
public class Rook extends Piece{

    public Rook(char colour) {
        super(colour);
    }

    //Tehdit durumunda taşın kaç puan getireceği ve tehdit durumu yok ise kaç puan getireceğini dönderen fonksiyon.
    @Override
    public double scorePiece() {
        if (threatA==true){
            return 2.5;
        }
        else {
            return 5.0;
        }
    }

    /* Taşın tehdit ettiği taşları bulmak için bu fonksiyon yazılmıştır.
       Kale düz, geri, sağ, sol gider. Sınırsız. Renk ayrımı yok.*/
    @Override
    public void threatE(int row, int column, Board board) {
        board.setCoordinate(row, column);
        while (board.forward(colour)) {}
        board.setCoordinate(row, column);
        while (board.back(colour)) {}
        board.setCoordinate(row, column);
        while (board.left(colour)) {}
        board.setCoordinate(row, column);
        while (board.right(colour)) {}
    }
}
