package com.company;

//Şah
public class King extends Piece{

    public King(char colour) {
        super(colour);
    }

    //Tehdit durumunda taşın kaç puan getireceği ve tehdit durumu yok ise kaç puan getireceğini dönderen fonksiyon.

    @Override
    public double scorePiece() {
        if (threatA==true){
            return 50.0;
        }
        else {
            return 100.0;
        }
    }

     /* Taşın tehdit ettiği taşları bulmak için bu fonksiyon yazılmıştır.
        Şah ileri, geri, sağ, sol, çapraz gider (Sadece 1 adım). Renk farketmez. */
    @Override
    public void threatE(int row, int column, Board board) {
        board.setCoordinate(row, column);
        board.forward(colour);
        board.setCoordinate(row, column);
        board.back(colour);
        board.setCoordinate(row, column);
        board.left(colour) ;
        board.setCoordinate(row, column);
        board.right(colour) ;
        board.setCoordinate(row, column);
        board.leftDiagonal(colour) ;
        board.setCoordinate(row, column);
        board.rightDiagonal(colour) ;
        board.setCoordinate(row, column);
        board.leftDiagonalBack(colour);
        board.setCoordinate(row, column);
        board.rightDiagonalBack(colour);
    }
}