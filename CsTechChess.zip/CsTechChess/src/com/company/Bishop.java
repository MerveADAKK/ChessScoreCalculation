package com.company;

//Fil
public class Bishop extends Piece {

    /*super bir üst sınıftan miras alan bir sınıfın üst sınıfın metotlarını , özelliklerini alt sınıftan çağırmamıza
     ve kullanmamıza olanak sağlar. Burada ki kullanımı:  Piece üst sınıfından colour kullanmaktır.*/
    public Bishop(char colour) {
        super(colour);
    }

    //Tehdit durumunda taşın kaç puan getireceği ve tehdit durumu yok ise kaç puan getireceğini dönderen fonksiyon.
    @Override
    public double scorePiece() {
        if (threatA==true){
            return 1.5;
        }
        else {
            return 3.0;
        }
    }

    /* Taşın tehdit ettiği taşları bulmak için bu fonksiyon yazılmıştır. Fil çapraz gider. Renk farketmez. While
    döngüsü ile sadece 1 çaprazına değil gidebileceği tüm çaprazlara bakılması sağlanmıştır. */
    @Override
    public void threatE(int row, int column, Board board) {
        board.setCoordinate(row, column);
        while (board.rightDiagonal(colour)) {}
        board.setCoordinate(row, column);
        while (board.leftDiagonal(colour)) {}
        board.setCoordinate(row, column);
        while (board.leftDiagonalBack(colour)) {}
        board.setCoordinate(row, column);
        while (board.rightDiagonalBack(colour)) {}
    }
}