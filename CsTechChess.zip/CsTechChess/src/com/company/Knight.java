package com.company;

//At
public class Knight extends Piece {
    public Knight(char colour) {
        super(colour);
    }


    //Tehdit durumunda taşın kaç puan getireceği ve tehdit durumu yok ise kaç puan getireceğini dönderen fonksiyon.
    @Override
    public double scorePiece() {
        if (threatA==true){
            return 1.5;
        }
        else {
            return 3.0;
        }
    }

    /* Taşın tehdit ettiği taşları bulmak için bu fonksiyon yazılmıştır.
       At L şeklinde gider. Siyah ve beyazda aynı şekilde tehdit eder. */

    @Override
    public void threatE(int row, int column, Board board) {
        board.setCoordinate(row, column);
        board.L1(colour);
        board.setCoordinate(row, column);
        board.L2(colour);
        board.setCoordinate(row, column);
        board.L3(colour);
        board.setCoordinate(row, column);
        board.L4(colour);
        board.setCoordinate(row, column);
        board.L5(colour);
        board.setCoordinate(row, column);
        board.L6(colour);
        board.setCoordinate(row, column);
        board.L7(colour);
        board.setCoordinate(row, column);
        board.L8(colour);
    }
}
