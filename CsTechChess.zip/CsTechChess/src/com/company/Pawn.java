package com.company;

//Piyon
public class Pawn extends Piece{

    public Pawn(char colour) {
        super(colour);
    }

    //Tehdit durumunda taşın kaç puan getireceği ve tehdit durumu yok ise kaç puan getireceğini dönderen fonksiyon.
    @Override
    public double scorePiece() {
        if (threatA==true){
            return 0.5;
        }
        else {
            return 1.0;
        }
    }

    /* Taşın tehdit ettiği taşları bulmak için bu fonksiyon yazılmıştır.
       Piyolar çaprazlarını tehdit eder. Siyah olan ileri, beyaz olan geri çapraz. */

    @Override
    public void threatE(int row, int column, Board board) {
        //Rengin siyah olması durumunda tehdit
        if (colour =='s') {
            board.setCoordinate(row, column);
            board.leftDiagonal(colour) ;
            board.setCoordinate(row, column);
            board.rightDiagonal(colour) ;

        }
        //Rengin beyaz olması durumunda tehdit
        else if (colour =='b'){
            board.setCoordinate(row, column);
            board.leftDiagonalBack(colour);
            board.setCoordinate(row, column);
            board.rightDiagonalBack(colour);
        }
    }
}