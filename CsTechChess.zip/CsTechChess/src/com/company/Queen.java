package com.company;

//Vezir
public class Queen extends Piece{

    public Queen(char colour) {
        super(colour);
    }

    //Tehdit durumunda taşın kaç puan getireceği ve tehdit durumu yok ise kaç puan getireceğini dönderen fonksiyon.
    @Override
    public double scorePiece() {
        if (threatA==true){
            return 4.5;
        }
        else {
            return 9.0;
        }
    }

     /* Taşın tehdit ettiği taşları bulmak için bu fonksiyon yazılmıştır.
     * Vezir her yöne sınırsız sayıda gidebilir.*/
    @Override
    public void threatE(int row, int column, Board board) {
        board.setCoordinate(row, column);
        while(board.forward(colour)){}
        board.setCoordinate(row, column);
        while(board.back(colour)){}
        board.setCoordinate(row, column);
        while(board.left(colour)){}
        board.setCoordinate(row, column);
        while(board.right(colour)){}
        board.setCoordinate(row, column);
        while(board.leftDiagonal(colour)){}
        board.setCoordinate(row, column);
        while(board.rightDiagonal(colour)){}
        board.setCoordinate(row, column);
        while(board.leftDiagonalBack(colour)){}
        board.setCoordinate(row, column);
        while(board.rightDiagonalBack(colour)){}
    }
}
