package com.company;

//Parent class
public abstract class Piece {

    //Tehdit altında mı ve rengi
    protected boolean threatA;
    protected char colour;

    //Constructor
    //Eğer tehdit true değilse otomatik olarak false
    public Piece(char r){
        threatA = false;
        colour = r;
    }

    //Getter ve setter
    public boolean isThreatA() {
        return threatA;
    }

    public void setThreatA(boolean threatA) {
        this.threatA = threatA;
    }

    public char getColour() {
        return colour;
    }

    public void setColour(char colour) {
        this.colour = colour;
    }

    //Soyut sınıfların içerisindeki soyut metotların gövdesi boş olması gerekir(Kullanılacak yere göre işlem farklılığı olacağından.)
    public abstract double scorePiece();

    public abstract void threatE(int row, int column, Board board);
}
