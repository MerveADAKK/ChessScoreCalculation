package com.company;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Board {
    private Piece[][] board;
    private int rowCoordinate;
    private int columnCoordinate;


    public void setCoordinate(int row, int column){
        rowCoordinate = row;
        columnCoordinate = column;
    }

    //Hesaplama yaparken koordinatların 0 dan büyük ve 7 den küçük olması gerekir. Bunun kontrolünün yapıldığı fonksiyon
    public boolean validCoordinate(int row, int column){
        if (row<0 || row>7 || column<0 || column>7){
            return false;
        }
        return true;
    }

    public boolean threat(char colour){
        //Gelen kordinatların doğru olup olmadığına bakıyor, eğer istenilen aralıkta değil ise false dönderiyor.
        if(!validCoordinate(rowCoordinate,columnCoordinate)){
            return false;
        }

        //rengine göre tehdit edip etmediğini kontrol ediyor tehdit ediyorsa taşın treat durumunu true yapıyor.
        Piece piece = board[rowCoordinate][columnCoordinate];
        if (piece == null) {
            return true;
        } else {
            if (piece.getColour() != colour) {
                piece.setThreatA(true);
            }
            return false;
        }
    }

    //text dosyamızdan verileri alıyor.
    public Board(String txtFile){
        board = new Piece[8][8];
        try {
            File myObj = new File(txtFile);
            Scanner myReader = new Scanner(myObj);

            //en üst taraf 8. satır olduğu için ilk index 7 olmalıdır.
            int rowNew=7;
            while (myReader.hasNextLine()) {
                //Satır satır okunup boşluk durumuna göre parçalanıyor.
                String data = myReader.nextLine();
                String[] pieces =data.split(" ");
                for (int i=0;i<8;i++) {
                    String piece = pieces[i];
                    if (!piece.equals("--")) {
                        // t değeri taşın hangi taş olduğunu alıyor.
                        char t=piece.charAt(0);
                        // r değeri taşın renk olduğunu alıyor.
                        char r=piece.charAt(1);

                        //taşın hangi taş olduğu kontrol edilip yeni obje oluşturuluyor. Bunuda board'a ekliyoruz.
                        if (t =='k') {
                            Rook k = new Rook(r);
                            board[rowNew][i] = k;
                        } else if (t =='p') {
                            Pawn k = new Pawn(r);
                            board[rowNew][i] = k;
                        } else if (t =='f') {
                            Bishop k = new Bishop(r);
                            board[rowNew][i] = k;
                        } else if (t =='a') {
                            Knight k = new Knight(r);
                            board[rowNew][i] = k;
                        } else if (t =='v') {
                            Queen k = new Queen(r);
                            board[rowNew][i] = k;
                        } else if (t =='s') {
                            King k = new King(r);
                            board[rowNew][i] = k;
                        }
                    }
                }
                rowNew--;
            }
            myReader.close();
        }catch (FileNotFoundException e) {
            System.out.println("! File does not exist !");
            e.printStackTrace();
        }
    }

    //1 ileri: satır sayısı 1 azalır(aşağı)
    public boolean forward(char colour){
        rowCoordinate--;
        return threat(colour);
    }

    //1 geri: satır sayısı 1 artar(yukarı)
    public boolean back(char colour){
        rowCoordinate++;
        return threat(colour);
    }

    //1 sol: sütun sayısı 1 azalır
    public boolean left(char colour){
        columnCoordinate--;
        return threat(colour);
    }

    //1 sağ: sütun sayısı 1 artar
    public boolean right(char colour){
        columnCoordinate++;
        return threat(colour);
    }

    //sol çapraz ileri
    public boolean leftDiagonal(char colour){
        rowCoordinate--;
        columnCoordinate--;
        return threat(colour);
    }

    //sağ çapraz ileri
    public boolean rightDiagonal(char colour){
        rowCoordinate--;
        columnCoordinate++;
        return threat(colour);
    }

    //sol çapraz geri
    public boolean leftDiagonalBack(char colour){
        rowCoordinate++;
        columnCoordinate--;
        return threat(colour);
    }

    //sağ çapraz geri
    public boolean rightDiagonalBack(char colour){
        rowCoordinate++;
        columnCoordinate++;
        return threat(colour);
    }

    //filin  hareketleri
    public boolean L1(char colour) {
        rowCoordinate+=2;
        columnCoordinate+=1;
        return threat(colour);
    }
    public boolean L2(char colour) {
        rowCoordinate+=1;
        columnCoordinate+=2;
        return threat(colour);
    }
    public boolean L3(char colour) {
        rowCoordinate+=2;
        columnCoordinate-=1;
        return threat(colour);
    }
    public boolean L4(char colour) {
        rowCoordinate-=1;
        columnCoordinate+=2;
        return threat(colour);
    }
    public boolean L5(char colour) {
        rowCoordinate-=2;
        columnCoordinate+=1;
        return threat(colour);
    }
    public boolean L6(char colour) {
        rowCoordinate-=2;
        columnCoordinate-=1;
        return threat(colour);
    }
    public boolean L7(char colour) {
        rowCoordinate-=1;
        columnCoordinate-=2;
        return threat(colour);
    }
    public boolean L8(char colour) {
        rowCoordinate+=1;
        columnCoordinate-=2;
        return threat(colour);
    }

    //Puanları hesaplamak için fonksiyon
    public void scoreCalculate(){
        for(int row=0; row<8; row++){
            for(int column=0; column<8; column++){
                Piece piece = board[row][column];
                if (piece != null){
                   piece.threatE(row,column,this);
                }
            }
        }

        double blackScore=0;
        double whiteScore=0;

        for (int row=0;row<8; row++) {
            for (int column=0;column<8; column++) {
                Piece piece = board[row][column];
                if (piece!=null) {
                    if (piece.getColour() =='b') {
                        whiteScore += piece.scorePiece();
                    } else if(piece.getColour() =='s')  {
                        blackScore += piece.scorePiece();;
                    }
                }
            }
        }
        //Ekrana sonucu yazdırma
        System.out.println("Siyah:"+blackScore+" Beyaz:" + whiteScore);
    }
}
