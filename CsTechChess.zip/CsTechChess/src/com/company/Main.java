package com.company;

public class Main {

    public static void main(String[] args) {
        //Text dosyasından verileri alma
        Board board = new Board("board3.txt");
        //Puan hesaplama
        board.scoreCalculate();
    }
}